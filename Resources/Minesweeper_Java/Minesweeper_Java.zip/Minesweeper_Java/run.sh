
java -classpath ".:jars/*" src/Main "$@"