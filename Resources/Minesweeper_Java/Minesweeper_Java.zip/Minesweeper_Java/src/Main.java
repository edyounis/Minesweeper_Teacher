package src;

import org.apache.commons.cli.*;
import java.io.*;

public class Main {
	public static void main(String[] args) throws Exception {
		String aiType = "myai";
		boolean debug_mode = false;
	
		World world = null;
		// ------------------------- Parse Options ---------------------------
        Options options = new Options();
        
        Option help = new Option("h", "help", false, "help");
        help.setRequired(false);
        options.addOption(help);
        
        Option file = new Option("f", "file", true, "file input");
        file.setRequired(false);
        options.addOption(file);

        Option manualMode = new Option("m", "manual", false, "manual mode");
        manualMode.setRequired(false);
        options.addOption(manualMode);
        
        Option randomMode = new Option("r", "random", false, "random mode");
        randomMode.setRequired(false);
        options.addOption(randomMode);
        
        Option verbose = new Option("v", "verbose", false, "verbose mode");
        verbose.setRequired(false);
        options.addOption(help);
        
        Option debug = new Option("d", "debug", false, "debug mode");
        debug.setRequired(false);
        options.addOption(debug);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd = null;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.out.println(e.getMessage());
            formatter.printHelp("Minesweeper", options);
            System.exit(1);
        }
        
        if (cmd.hasOption("help")) {
        	formatter.printHelp("Usage", options);
        	System.exit(0);
        }
        
        // Get option values
        String filename = cmd.getOptionValue("file");
        
        // Random AI has priority over Manual AI if both flags are given
        if (cmd.hasOption("random")) {
        	aiType = "random";
        } else if (cmd.hasOption("manual")) {
        	aiType = "manual";
        }
        
        if (cmd.hasOption("debug")) {
        	debug_mode = true;
        }
        
		// Create the world
        int completed = 0;
        int died = 0;
		if (filename != null) {
			File f = new File(filename);
			if (f.isDirectory()) {
				System.out.println("Running on Worlds in... " + filename);
				File worldsDir = new File(filename);
				for (File worldFile : worldsDir.listFiles()) {
					System.out.println("Running on " + worldFile.getCanonicalPath());
					world = new World(worldFile.getCanonicalPath(), aiType, debug_mode);
					double score = world.run();
					if (score > 100) {
						completed++;
					} else if (score < -10) {
						died++;
					}
				}
				System.out.println("Completed " + completed);
				System.out.println("Died: " + died);
			} else if (f.isFile()) {
				System.out.println("Running on world " + filename);
				world = new World(filename, aiType, debug_mode);
				world.run();
			}
		} else {
			System.out.print("file null...running on random world.");
			world = new World(null, aiType, debug_mode);
			world.run();
		}
	}
}
